from django.shortcuts import render
from .models import Payment  
from .forms import PaymentForm   



def paymentview(request):
	form=PaymentForm()
	if request.method=="POST":
		form=PaymentForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"New Payment Added"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Invalid Data Found","error":form.errors})
	else:
		return render(request,"payment.html",{"form":form})


def list_all_payment(request):
	records=Payment.objects.all()
	return render(request,"list_all_payment.html",{"records":records})


def payment_details(request,payment_id):
	payment=Payment.objects.filter(payment_id=payment_id).first()
	if payment:
		return render(request,'payment_details.html',{'payment':payment})
	return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid"})


