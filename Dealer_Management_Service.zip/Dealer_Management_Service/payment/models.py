from django.db import models


class Payment(models.Model):
	payment_id=models.CharField(max_length=50)
	amount=models.CharField(max_length=50)
	service_id=models.CharField(max_length=50)
	mode_of_payment=models.CharField(max_length=50)


def __str__(self):
	return self.payment_id.tittle()