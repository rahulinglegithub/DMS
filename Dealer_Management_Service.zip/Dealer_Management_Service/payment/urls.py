from django.urls import path 
from.views import paymentview,list_all_payment,payment_details


urlpatterns=[path("",paymentview),
			path("list_all_payment/",list_all_payment),
			path("list_all_payment/<str:payment_id>",payment_details)



]