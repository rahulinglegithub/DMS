from django.urls import path 
from .views import invoiceview ,list_all_invoice,invoice_details


urlpatterns=[

			path("",invoiceview),
			path("list_all_invoice/",list_all_invoice),
			path("list_all_invoice/<str:id>",invoice_details)

]



