from django.shortcuts import render
from .models import Invoice  
from .forms import InvoiceForm  



def invoiceview(request):
	form=InvoiceForm()
	if request.method=="POST":
		form=InvoiceForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"New Invoice Created"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid","error":form.errors})
	else:
		return render(request,"invoice.html",{"form":form})
		

def list_all_invoice(request):
	records=Invoice.objects.all()
	return render(request,"list_all_invoice.html",{"records":records})
	

def invoice_details(request,id):
	invoice=Invoice.objects.filter(id=id).first()
	if invoice:
		return render(request,'invoice_details.html',{'invoice':invoice})
	return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid"})


