from django.db import models


class Invoice(models.Model):
	service_id=models.CharField(max_length=50)
	charges=models.FloatField()
	service_labour_charges=models.FloatField()


def __str__(self):
	return self.service_id.title()