from django.shortcuts import render
from .models import Employee 
from .forms import EmployeeForm  


def employeeview(request):
	form=EmployeeForm()
	if request.method=="POST":
		form=EmployeeForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"New Employee Added"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid","error":form.errors})
	else:
		return render(request,"employee.html",{"form":form})
		

def list_all_employee(request):
	records=Employee.objects.all()
	return render(request,"list_all_employee.html",{"records":records})

def employee_details(request,id):
	employee=Employee.objects.filter(id=id).first()
	if employee:
		return render(request,'employee_details.html',{'employee':employee})
	return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid"})



	