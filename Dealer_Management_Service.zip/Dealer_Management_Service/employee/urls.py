from django.urls import path
from .views import employeeview,list_all_employee,employee_details

urlpatterns = [
    path("",employeeview),
    path("list_all_employee/",list_all_employee),
    path("list_all_employee/<int:id>",employee_details)
]