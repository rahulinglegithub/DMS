from django import forms  
from .models import Customer,CustomerDetails,VehicleDetails,ServiceStatus  


class CustomerForm(forms.ModelForm):
	class Meta:
		model=Customer
		fields='__all__'
		# fields=["customer_name","mobile_no","email_address","vehicle_no","vehicle_model","in_date","in_time"]


class CustomerDetailsForm(forms.ModelForm):
	class Meta:
		model=CustomerDetails 
		fields=["customer_name","mobile_no","email_address","home_adress"]


class VehicleDetailsForm(forms.ModelForm):
	class Meta:
		model=VehicleDetails   
		fields='__all__'
		# fields=["customer_id","vehicle_no","vehicle_model","in_date"]

class ServiceStatusForm(forms.ModelForm):
	class Meta:
		model=ServiceStatus   
		fields=["customer_name","vehicle_no","vehicle_model","vehicle_status"]