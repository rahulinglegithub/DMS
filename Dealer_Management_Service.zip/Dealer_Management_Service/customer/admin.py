from django.contrib import admin


# from .models import Customer,CustomerDetails,VehicleDetails,ServiceStatus

# class VehicleDetailsAdmin(admin.StackedInline):
# 	model = VehicleDetails

# @admin.register(Customer)
# class CustomerAdmin(admin.ModelAdmin):
# 	inlines=[VehicleDetailsAdmin]

# 	class Meta:
# 		model=Customer

# @admin.register(VehicleDetails)
# class VehicleDetailsAdmin(admin.ModelAdmin):
	# pass 

# from .models import PropertieDetails, PropertieImages

# class PropertieImageAdmin(admin.StackedInline):
# 	model = PropertieImages

# @admin.register(PropertieDetails)
# class PropertieDetailsAdmin(admin.ModelAdmin):
# 	inlines = [PropertieImageAdmin]

# 	class Meta:
# 		model = PropertieDetails

# @admin.register(PropertieImages)
# class PropertieImageAdmin(admin.ModelAdmin):
# 	pass














