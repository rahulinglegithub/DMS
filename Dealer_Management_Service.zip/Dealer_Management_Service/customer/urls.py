from django.urls import path
from .views import customerview,list_all_customer,customer_details,customerdetailsview,vehicledetailsview,servicestatusview

urlpatterns = [
    path("",customerview),
    path("list_all_customer/",list_all_customer),
    path("customerdetailsview/",customerdetailsview),
    path("vehicledetailsview/",vehicledetailsview),
    path("servicestatusview/",servicestatusview),
    path("list_all_customer/<str:id>",customer_details)
    

]