from django.db import models

class Customer(models.Model):
	customer_name=models.CharField(max_length=50)
	mobile_no=models.IntegerField()
	email_address=models.EmailField(max_length=25)
	vehicle_no=models.CharField(max_length=25)
	vehicle_model=models.CharField(max_length=25)
	in_date=models.DateTimeField(null=False)
	in_time=models.TimeField(auto_now=False, auto_now_add=False,null=True)

	def __str__(self):
		return self.vehicle_no.title()

class CustomerDetails(models.Model):
	customer_name=models.CharField(max_length=50)
	mobile_no=models.IntegerField()
	email_address=models.EmailField(max_length=25)
	home_adress=models.CharField(max_length=50)
	
# def __str__(self):
# 	return self.customer_name.title()


class VehicleDetails(models.Model):
	customer_id=models.CharField(max_length=50)
	vehicle_no=models.ForeignKey(Customer, on_delete=models.SET_NULL, blank=True, null=True)
	vehicle_model=models.CharField(max_length=50)
	in_date=models.DateTimeField(null=False)

	def __str__(self):
		return self.customer_id.title()

class ServiceStatus(models.Model):
	customer_name=models.CharField(max_length=50)
	vehicle_no=models.CharField(max_length=50)
	vehicle_model=models.CharField(max_length=50)
	vehicle_status=models.CharField(max_length=50)