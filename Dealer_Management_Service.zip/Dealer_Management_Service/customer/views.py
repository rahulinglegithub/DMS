from django.shortcuts import render
from .models import Customer,CustomerDetails,VehicleDetails     
from .forms import CustomerForm,CustomerDetailsForm,VehicleDetailsForm,ServiceStatusForm


def customerview(request):
	form=CustomerForm()
	if request.method=="POST":
		form=CustomerForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"New Customer Added"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid","error":form.errors})
	else:
		return render(request,"customer.html",{"form":form})


def customerdetailsview(request):
	form=CustomerDetailsForm()
	if request.method=="POST":
		form=CustomerDetailsForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"Customer Details Added"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid","error":form.errors})
	else:
		return render(request,"add_customer_details.html",{"form":form})


def vehicledetailsview(request):
	form=VehicleDetailsForm()
	if request.method=="POST":
		form=VehicleDetailsForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"Vehicle Details Added"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid","error":form.errors})
	else:
		return render(request,"add_vehicle_details.html",{"form":form})


def servicestatusview(request):
	form=ServiceStatusForm()
	if request.method=="POST":
		form=ServiceStatusForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"Service Status Saved successfully"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid","error":form.errors})
	else:
		return render(request,"service_status.html",{"form":form})



def list_all_customer(request):
	records =Customer.objects.all()
	return render(request, 'list_all_customer.html', {'records': records})


def customer_details(request,id):
	customer=Customer.objects.filter(id=id).first()
	if customer:
		return render(request,'customer_details.html',{'customer':customer})
	return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid"})



	

	

	


