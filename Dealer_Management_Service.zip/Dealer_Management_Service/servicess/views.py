from django.shortcuts import render
from .models import Servicess    
from .forms import ServicessForm  


def servicessview(request):
	form=ServicessForm()
	if request.method=="POST":
		form=ServicessForm(request.POST)
		if form.is_valid():
			form.save()
			return render(request,"success_response.html",{"data":"New Serviecss Added"})
		else:
			return render(request,"invalid_form_data.html",{"data":"Data Is Invalid","error":form.errors})
	else:
		return render(request,"servicess.html",{"form":form})

def list_all_servicess(request):
	records=Servicess.objects.all()
	return render(request,"list_all_servicess.html",{"records":records})

def servicess_details(request,service_id):
	servicess=Servicess.objects.filter(service_id=service_id).first()
	if servicess:
		return render(request,'servicess_details.html',{'servicess':servicess})
	return render(request,"invalid_form_data.html",{"data":"Data Is Not Valid"})




