from django.urls import path  
from .views import servicessview,list_all_servicess,servicess_details    


urlpatterns=[
			path("",servicessview),
			path("list_all_servicess/",list_all_servicess),
			path("list_all_servicess/<str:service_id>",servicess_details)

]