from django.apps import AppConfig


class ServicessConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "servicess"
