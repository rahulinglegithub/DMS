from django.db import models
from customer.models import Customer,VehicleDetails


service_type = (
    ("1st free service", "1st Free Service"),
    ("2nd free service", "2nd Free Service"),
    ("3rd free service", "3rd Free Service"),
    ("paid service", "Paid Service"),
    ("part replacement", "Part Replacement"),
    ("pms 10", "Pms 10"),
    ("pms 20", "Pms 20"),
    ("pms 30", "Pms 30"),
    ("pms 40", "Pms 40"),
    ("pms 50", "Pms 50"),
    ("pms 60", "Pms 60"),
    ("pms 70", "Pms 70"),
    ("pms 80", "Pms 80"),
    ("pms 90", "Pms 90"),
    ("pms 100", "Pms 100")
)

class Servicess(models.Model):
	service_id=models.CharField(max_length=50)
	service_type=models.CharField(max_length=50,choices = service_type,
                                  default = 'paid service')
	vehicle_no=models.ForeignKey(Customer , on_delete=models.SET_NULL, blank=True, null=True)
	employee_id=models.CharField(max_length=50)
	service_status=models.CharField(max_length=50)
	in_date=models.DateTimeField(null=False)
	in_time=models.TimeField(auto_now=False, auto_now_add=False,null=True)


# employee_id=models.AutoField(primary_key=True)
# service_id=models.AutoField(db_column='id',primary_key=True
# service_id=models.AutoField(service_id='service_id',primary_key=True)
# bid = models.AutoField(db_column='BID', primary_key=True)
# service_id=models.AutoField(db_column="SERVICE_ID",primary_key=True)
# service_id=models.AutoField(db_column='service_id',primary_key=True)