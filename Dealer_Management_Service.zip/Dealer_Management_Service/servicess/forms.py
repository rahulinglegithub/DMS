from django import forms 
from .models import Servicess  



class ServicessForm(forms.ModelForm):
	class Meta:
		model=Servicess 
		fields=["service_id","service_type","vehicle_no","employee_id","service_status","in_date","in_time"]

		